COMP249 2016 FlowTow Starter Kit
================================

This repository contains the starter kit for the 2016 COMP249 project FlowTow.
You can see a running version of the project at http://comp249.stevecassidy.net/
which contains a copy of the assignment requirements. There is also a copy included
here for reference.  

Please contact Steve Cassidy if you have questions.
